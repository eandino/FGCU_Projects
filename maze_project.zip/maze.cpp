/****************************************************************************************************************************************
 * File: maze.cpp
 * Author: Eddie L. Andino
 * Class: COP2001; 201805; 50135
 * Purpose: Random maze generator using a recursion algorithm
****************************************************************************************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>
#include <time.h>
#include <sstream>
#include <stdlib.h>

#define BYTE unsigned char							// BYTE is a text macro for an actual data type

const int MAZE_ROWS = 3;
const int MAZE_COLS = 3;

const BYTE CELL_TOP = 1;
const BYTE CELL_BOTTOM = 2;
const BYTE CELL_LEFT = 4;
const BYTE CELL_RIGHT = 8;
const BYTE CELL_VISITED = 16;

// starting cell
const int START_CELL_ROW = 0;
const int START_CELL_COL = 0;
const int START_WALL = CELL_LEFT;

// ending cell
const int END_CELL_ROW = 2;
const int END_CELL_COL = 2;
const int END_WALL = CELL_RIGHT;

// location indexes
const int CELL_ROW_INDEX = 0;
const int CELL_COL_INDEX = 1;

// Maze print characters
const char OUT_TOP_LEFT			= '-';
const char OUT_TOP_MID			= '-';
const char OUT_TOP_RIGHT		= '-';
const char OUT_SIDE_LEFT		= '|';
const char OUT_SIDE_RIGHT		= '|';
const char OUT_BOT_LEFT			= '-';
const char OUT_BOT_MID			= '-';
const char OUT_BOT_RIGHT		= '-';
const char INSIDE_MIDDLE		= '+';
const char CELL_TOP_BOT			= '-';
const char CELL_LEFT_RIGHT		= '|';
const char CELL_OPEN_HORZ		= ' ';
const char CELL_OPEN_VERT		= ' ';
const char CELL_VISITED_ON		= '.';
const char CELL_VISITED_OFF		= ' ';

// function declarations
bool hasAvailableNeighbors(BYTE cells[][MAZE_COLS], int location[]);
bool hasUnvisitedCells(BYTE cells[][MAZE_COLS]);
void initMaze(BYTE cells[][MAZE_COLS]);
void chooseRandomNeighbor(BYTE cells[][MAZE_COLS], int current[], int neighbor[]);
void removeWalls(BYTE cells[][MAZE_COLS], int current[], int neighbor[]);
int pushStack(int stack[][2], int location[], int stackPoint);
void popStack(int stack[][2], int location[], int& stackPoint);
void copyOneLocTwo(int locOne[], int locTwo[]);
void printMaze(BYTE cells[][MAZE_COLS]);
void printMazeDebug(BYTE cells[][MAZE_COLS]);

int main() {
	char tmp;																		// Pause the program

	std::cout << "Welcome to the Maze Program!" << std::endl << std::endl;

	//init random generator
	srand(time(NULL));																// stdlib; time.h

	// Storage for the maze
	BYTE maze[MAZE_ROWS][MAZE_COLS] = { 0 };

	// storage for our stack of visited cells
	int stack[MAZE_ROWS * MAZE_COLS][2] = { 0 };

	int stackPointer = -1;			// empty stack value

	initMaze(maze);

	// set starting cell
	int startCell[2];
	startCell[CELL_ROW_INDEX] = START_CELL_ROW;
	startCell[CELL_COL_INDEX] = START_CELL_COL;
	// turn off starting wall
	maze[startCell[CELL_ROW_INDEX]][startCell[CELL_COL_INDEX]] ^= START_WALL;

	// turn off ending wall
	maze[END_CELL_ROW][END_CELL_COL] ^= END_WALL;

	printMaze(maze);
	std::cout << std::endl;

	printMazeDebug(maze);
	std::cout << std::endl;

	// Pause program
	std::cin >> tmp;


	// 1.) Make the initial cell the current cell and mark it as visited
	int currCell[2];
	copyOneLocTwo(startCell, currCell);
	// Mark visited flag
	maze[currCell[CELL_ROW_INDEX]][currCell[CELL_COL_INDEX]] ^= CELL_VISITED;

	// 2.) While there are unvisited cells
	while(hasUnvisitedCells(maze)) {
		
		// i. If the current cell has any neighbors which have not been visited
		if(hasAvailableNeighbors(maze, currCell)) {
		
			// 1.) Choose randomly one of the unvisited neighbors
			int neighborCell[2] = { 0 };
			chooseRandomNeighbor(maze, currCell, neighborCell);

			// 2. Push the current cell to stack
			stackPointer = pushStack(stack, currCell, stackPointer);

			// 3. Remove walls between the current cell and the chosen
			removeWalls(maze, currCell, neighborCell);

			// 4. Make the chosen cell the current cell and mark it as visited
			copyOneLocTwo(neighborCell, currCell);
			// mark visited flag
			maze[currCell[CELL_ROW_INDEX]][currCell[CELL_COL_INDEX]] ^= CELL_VISITED;

			// 5. Print the maze
			printMaze(maze);
			std::cout << std::endl;

			printMazeDebug(maze);
			std::cout << std::endl;
		
		} // end has any neighbors

		// ii. Else if the stack is not empty
		else if(stackPointer >= 0) {
			
			// 1. Pop last cell from the stack into current
			popStack(stack, currCell, stackPointer);
		}
	} // end unvisited cells

	  // 3. Print the maze
	printMaze(maze);
	std::cout << std::endl;

	printMazeDebug(maze);
	std::cout << std::endl;

	std::cout << std::endl << std::endl;
	std::cout << "Thank you for using the program! \n Goodbye" << std::endl;

	// Pause the program
	std::cin >> tmp;

	return 0;
} // end main


/*
 * This function will find whether there is a neighbor to 
 * the current cell or not.
 * @param cells[][] - the size of the maze
 * @param location[] - Location of the current cell
 * @return bool - has available neighbors
 */
bool hasAvailableNeighbors(BYTE cells[][MAZE_COLS], int location[]) {
	//bool isAvailable = true;
	// check if has neighbor above 
	if(location[CELL_ROW_INDEX] > 0) {
		// check if not visited
		if(!(cells[location[CELL_ROW_INDEX] - 1][location[CELL_COL_INDEX]] & CELL_VISITED)) {
			return true;
		}
	}

	// check if has neighbor below 
	if(location[CELL_ROW_INDEX] < MAZE_ROWS - 1) {
		// check if not visited
		if(!(cells[location[CELL_ROW_INDEX] + 1][location[CELL_COL_INDEX]] & CELL_VISITED)) {
			return true;
		}
	}

	// check if has neighbor left 
	if(location[CELL_COL_INDEX] > 0) {
		// check if not visited
		if(!(cells[location[CELL_ROW_INDEX]][location[CELL_COL_INDEX] - 1] & CELL_VISITED)) {
			return true;
		}
	}

	// check if has neighbor right
	if(location[CELL_COL_INDEX] < MAZE_COLS - 1) {
		// check if not visited
		if(!(cells[location[CELL_ROW_INDEX]][location[CELL_COL_INDEX] + 1] & CELL_VISITED)) {
			return true;
		}
	}

	return false;
} // end hasAvailableNeighbors


/*
 * This function will check whether the maze has any unvisited
 * cells
 * @param cells[][] - The size of the maze
 * @return bool - unvisited cells
*/
bool hasUnvisitedCells(BYTE cells[][MAZE_COLS]) {
	bool isVisited = true;

	int row = 0;
	while(isVisited && row < MAZE_ROWS) {
	
		int col = 0;
		while(col < MAZE_COLS && isVisited) {
			isVisited = cells[row][col] & CELL_VISITED;
			col++;
		}

		row++;
	}

	return !isVisited;
} // end hasUnvisitedCells


/**
 * Initialize maze array elements to turn all
 * walls on and visited off
 * @param cells[][] - the grid of cells in the maze
 * @return void
*/
void initMaze(BYTE cells[][MAZE_COLS]) {

	for(int row = 0; row < MAZE_ROWS; row++) {
		for(int col = 0; col < MAZE_COLS; col++) {
			cells[row][col] = CELL_TOP | CELL_BOTTOM | CELL_LEFT | CELL_RIGHT;
		}
	}

} // end initMaze


/*
 * Function will choose a random neighbor to jump to
 * for the mouse
 * @param cells[][] - The size of the maze
 * @param current[] - The position of the mouse
 * @param neighbor[] - the position of the neighbor cell
 * @return void
*/
void chooseRandomNeighbor(BYTE cells[][MAZE_COLS], int current[], int neighbor[]) {
	bool done = false;

	while(!done) {
	
		int randNeighbor = rand() % 4;						// random 0...3

		switch(randNeighbor) {
		
		case 0:												// TOP
			if(current[CELL_ROW_INDEX] > 0) {
				if(!(cells[current[CELL_ROW_INDEX] - 1][current[CELL_COL_INDEX]] & CELL_VISITED)) {
					neighbor[CELL_ROW_INDEX] = current[CELL_ROW_INDEX] - 1;
					neighbor[CELL_COL_INDEX] = current[CELL_COL_INDEX];
					done = true;
				}
			} 
			break;
		
		case 1:												// BOTTOM
			if(current[CELL_ROW_INDEX] < MAZE_ROWS - 1) {
				if(!(cells[current[CELL_ROW_INDEX] + 1][current[CELL_COL_INDEX]] & CELL_VISITED)) {
					neighbor[CELL_ROW_INDEX] = current[CELL_ROW_INDEX] + 1;
					neighbor[CELL_COL_INDEX] = current[CELL_COL_INDEX];
					done = true;
				}
			}
			break;

		case 2:												// LEFT
			if(current[CELL_COL_INDEX] > 0) {
				if(!(cells[current[CELL_ROW_INDEX]][current[CELL_COL_INDEX] - 1] & CELL_VISITED)) {
					neighbor[CELL_ROW_INDEX] = current[CELL_ROW_INDEX];
					neighbor[CELL_COL_INDEX] = current[CELL_COL_INDEX] - 1;
					done = true;
				}
			}
			break;

		case 3:												// RIGHT
			if(current[CELL_COL_INDEX] < MAZE_COLS - 1) {
				if(!(cells[current[CELL_ROW_INDEX]][current[CELL_COL_INDEX] + 1] & CELL_VISITED)) {
					neighbor[CELL_ROW_INDEX] = current[CELL_ROW_INDEX];
					neighbor[CELL_COL_INDEX] = current[CELL_COL_INDEX] + 1;
					done = true;
				}
			}
			break;
		} // end switch

	} // end while

} // end chooseRandomNeighbor


/**
 * Remove walls between the current cell and the chosen
 * @param cells[][] - Size of the array
 * @param current[] - Current position on the array
 * @param neighbor[] - the location of the cell wall to be removed
 * @return void
*/
void removeWalls(BYTE cells[][MAZE_COLS], int current[], int neighbor[]) {

	// test for location of current and neighbor

	// test for neighbor above
	if(neighbor[CELL_ROW_INDEX] < current[CELL_ROW_INDEX]) {
		cells[neighbor[CELL_ROW_INDEX]][neighbor[CELL_COL_INDEX]] ^= CELL_BOTTOM;		// toggle cell wall off
		cells[current[CELL_ROW_INDEX]][current[CELL_COL_INDEX]] ^= CELL_TOP;			// toggle cell wall off
	} 
	// test for neighbor below
	else if(neighbor[CELL_ROW_INDEX] > current[CELL_ROW_INDEX]) {
		cells[neighbor[CELL_ROW_INDEX]][neighbor[CELL_COL_INDEX]] ^= CELL_TOP;			// toggle cell wall off
		cells[current[CELL_ROW_INDEX]][current[CELL_COL_INDEX]] ^= CELL_BOTTOM;			// toggle cell wall off
	}
	// test for neighbor left
	else if(neighbor[CELL_COL_INDEX] < current[CELL_COL_INDEX]) {
		cells[neighbor[CELL_ROW_INDEX]][neighbor[CELL_COL_INDEX]] ^= CELL_RIGHT;		// toggle cell wall off
		cells[current[CELL_ROW_INDEX]][current[CELL_COL_INDEX]] ^= CELL_LEFT;			// toggle cell wall off
	}
	// neighbor must be right
	else {
		cells[neighbor[CELL_ROW_INDEX]][neighbor[CELL_COL_INDEX]] ^= CELL_LEFT;			// toggle cell wall off
		cells[current[CELL_ROW_INDEX]][current[CELL_COL_INDEX]] ^= CELL_RIGHT;			// toggle cell wall off
	}
} // end removeWalls


/**
 * Adds a cell location onto the stack
 * @param stack - the location stack
 * @param location - row & col of a maze cell
 * @param stackPoint - last location added to stack
 * @return int - new stack pointer
*/
int pushStack(int stack[][2], int location[], int stackPoint) {
	int spNew = stackPoint;

	spNew++;					// move sp up the stack
	copyOneLocTwo(location, stack[spNew]);

	return spNew;
}


/**
 * Pull a cell location off the stack
 * @param stack - the location stack
 * @param location - row & col of a maze cell
 * @param stackPoint IN/OUT- last location added to stack and return new
 * @return int - new stack pointer
*/
void popStack(int stack[][2], int location[], int& stackPoint) {
	// the '&' means "adress of..."

	copyOneLocTwo(stack[stackPoint], location);
	stackPoint--;
}


/**
 * This function is to copy the location of the current cell
 * @param locOne[] - Row location of the cell
 * @param locTwo[] - Column location of the cell
 * return void
*/
void copyOneLocTwo(int locOne[], int locTwo[]) {
	
	locTwo[CELL_ROW_INDEX] = locOne[CELL_ROW_INDEX];
	locTwo[CELL_COL_INDEX] = locOne[CELL_COL_INDEX];
}

/**
 * Printing maze to the console
 * @param cells[][] - The size of the array
 * return void
*/
void printMaze(BYTE cells[][MAZE_COLS]) {

	for(int row = 0; row < MAZE_ROWS; row++) {

		// print left margin
		std::cout << ' ' << ' ';
		
		// Print the top row of the cells
		for(int col = 0; col < MAZE_COLS; col++) {
			
			/*** print left spacer ***/

			// are we on the top row
			if(row == 0) {

				// are we on the left wall
				if(col == 0) {
					std::cout << OUT_TOP_LEFT;
				} else {
					std::cout << OUT_TOP_MID;
				}

			} else { // not on top row

				// are we on the left wall
				if(col == 0) {
					std::cout << OUT_SIDE_LEFT;
				} else {
					std::cout << INSIDE_MIDDLE;
				}

			} // print top left spacer
			
			/*** print cell top ***/

			if(cells[row][col] & CELL_TOP) {
				std::cout << CELL_TOP_BOT;
			} else {
				std::cout << CELL_OPEN_HORZ;
			}

			// print last right spacer
			if(col == MAZE_COLS - 1) {
				// top row
				if(row == 0) {
					std::cout << OUT_TOP_RIGHT;
				} else { // not top row
					std::cout << OUT_SIDE_RIGHT;
				}
			}

		} // print top row

		// end top walls
		std::cout << std::endl;

		// print left margin
		std::cout << ' ' << ' ';

		// print side walls of the cells
		for(int col = 0; col < MAZE_COLS; col++) {
			
			// print cell left side wall
			if(cells[row][col] & CELL_LEFT) {
				std::cout << CELL_LEFT_RIGHT;
			} else {
				std::cout << CELL_OPEN_VERT;
			}

			// print cell visited
			if(cells[row][col] & CELL_VISITED) {
				std::cout << CELL_VISITED_ON;
			} else {
				std::cout << CELL_VISITED_OFF;
			}

			// print right wall
			if(col == MAZE_COLS - 1) {
				// print cell left side wall
				if(cells[row][col] & CELL_RIGHT) {
					std::cout << CELL_LEFT_RIGHT;
				} else {
					std::cout << CELL_OPEN_VERT;
				}
			}
		} // print side walls

		// after side walls
		std::cout << std::endl;

		// print bottom row
		if(row == MAZE_ROWS - 1) {

			// print left margin
			std::cout << ' ' << ' ';
			
			// print the bottom row of the cell walls
			for(int col = 0; col < MAZE_COLS; col++) {
				
				// print spacer
				if(col == 0) {
					std::cout << OUT_BOT_LEFT;
				} else {
					std::cout << OUT_BOT_MID;
				}

				// print cell bottom wall
				if(cells[row][col] & CELL_BOTTOM) {
					std::cout << CELL_TOP_BOT;
				} else {
					std::cout << CELL_OPEN_HORZ;
				}

				// print right corner
				if(col == MAZE_COLS - 1) {
					std::cout << OUT_BOT_RIGHT;
				}

			} // bottom walls

			// end the cells
			std::cout << std::endl;

		} // bottom row
		
	}	// ends row loop

} // end printMaze


/**
 * Printing the maze cell values to the console
 * @param cells - the grid of cells in the maze
 * @return void
*/
void printMazeDebug(BYTE cells[][MAZE_COLS]) {

	for(int row = 0; row < MAZE_ROWS; row++) {
		for(int col = 0; col < MAZE_COLS; col++) {
			std::cout << std::to_string(int(cells[row][col])) << " ";
		}
		std::cout << std::endl;
	}

} // end printMazeDebug


/*
	 * We can store top, left, right, bottom and visited (true or false) values
	 * into one single variable as shown below.
	 * T= top, L= left, R= right, B= bottom, V= visited.
	 *----------------------------------
	 * int 0000 0000:
	 * 0  0  0  0    0  0  0  0  
	 *         (V)  (R)(L)(B)(T)
	 *----------------------------------
	 * Top		1	-> 0000 0001
	 * Bottom	2	-> 0000 0010
	 * Left		4	-> 0000 0100
	 * Right	8	-> 0000 1000
	 * Visited	16	-> 0001 0000
	*/


/* Backup
bool hasUnvisitedCells(BYTE cells[][MAZE_COLS]) {
bool isVisited = true;

int row = 0;
while(isVisited && row < MAZE_ROWS - 1) {

int col = 0;
while(isVisited && col < MAZE_COLS - 1) {

isVisited = cells[row][col] & CELL_VISITED;
col++;
}

row++;
}

return !isVisited;
} // end hasUnvisitedCells
*/